# Shadow RPG (标题未定)

## Introduction
在2017年的暑假，不来一起做些什么吗？

不来开个大坑吗？比如...用Rust来写个RPG。

## Staff
### Cast
未定
<del>其实不一定会有</del>

### Programmers
* SJoshua
* Shuenhoy

### Scriptwriter
* Fuhei Cat (不知道腹黑猫干不干(逃

### Illustrators
* Maki
* Misaki
* Fuhei Cat (我也不知道腹黑猫干不干这个(逃

## Story
未定

## System
未定

## Schedule
未定

