# Licence
## Definition
* "你" 指代非 SF Software 成员的任何人.
* "代码" 指代该项目中的程序源码.
* "素材" 指代该项目中的原创素材、文字、脚本.

## Permission
* 你可以: View 及 Edit 代码.
* 你可以: 在非商业项目中使用或再发布代码.
* 你可以: View 素材.

## Condition
* 你需要: 注明代码的来源.

## Limitation
* 你不能: 商业使用代码或素材.
* 你不能: 修改或再发布素材.

## Copyright
SF Software © 2017 Summer
